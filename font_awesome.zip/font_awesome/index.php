<?php
		header('location:html_part/mainpage.html');
?>